create function searchnumberlicense(start character varying) returns TABLE(name character varying, unp character varying, numberform character varying, numberdesicion character varying, activity character varying)
LANGUAGE plpgsql
AS $$
begin
  Return query
  SELECT  ulandie.name, ulandie.unp, license.numberform, license.numberdesicion, licenseactivity.name as activity FROM ulandie
    INNER JOIN sisslr.license on license."ulandiЕ_id" =ulandie.id
    INNER JOIN sisslr.licenseactivity  ON license.licenseactivity_id = licenseactivity.id
  WHERE license.numberform   ILIKE (start) Order by license.numberform LIMIT 10 ;
END
$$;
