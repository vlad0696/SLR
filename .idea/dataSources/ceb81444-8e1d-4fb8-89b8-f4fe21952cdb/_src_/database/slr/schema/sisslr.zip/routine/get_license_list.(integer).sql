create function get_license_list(page integer) returns TABLE(id bigint, numberform character varying, desiction character varying, activityname character varying, ulanidenumber character varying, unp bigint)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN  QUERY SELECT license.id, license.numberform, license.numberdesicion, activity.name, ulandie.name, license.unpegr
                FROM license
                  INNER JOIN  ulandie ON license."ulandiЕ_id" = ulandie.id
                  INNER JOIN licenseactivity activity ON license.licenseactivity_id = activity.id
                WHERE license.dateend > now()
                ORDER BY license.id  LIMIT  20 OFFSET page;
END;
$$;
