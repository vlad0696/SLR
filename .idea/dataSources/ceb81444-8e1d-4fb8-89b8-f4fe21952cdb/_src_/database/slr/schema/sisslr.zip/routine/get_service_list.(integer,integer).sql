create function get_service_list(start__id integer, end_id integer) returns TABLE(id bigint, name character varying, localitynameshort character varying, localityname character varying)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN  QUERY SELECT license.id, licenseservices.name,typelocality.nameshort, administrativeterritories.localityname FROM license
    INNER JOIN licenseservicescross ON license.id = licenseservicescross.license_id
    INNER JOIN licenseservices ON licenseservicescross.licenseservices_id = licenseservices.id
    INNER JOIN licensedterritory on licenseservicescross.licensedterritory_id = licensedterritory.id
    INNER JOIN administrativeterritories on licensedterritory.administrativeterritories_id = administrativeterritories.id
    INNER JOIN typelocality on administrativeterritories.typelocality_id = typelocality.id
  WHERE enddatetime>now() and (license.id BETWEEN start__id AND end_id) ORDER BY license.id, name  ;
END;
$$;
