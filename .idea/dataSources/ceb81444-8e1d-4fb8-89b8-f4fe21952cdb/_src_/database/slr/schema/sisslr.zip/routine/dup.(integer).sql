create function dup(integer) returns TABLE(f1 integer, f2 text)
LANGUAGE SQL
AS $$
SELECT $1, CAST($1 AS text) || ' is text'
$$;
