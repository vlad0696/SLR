create function getterritories1() returns TABLE(districtname character varying, localityname character varying)
LANGUAGE plpgsql
AS $$
begin
  Return query
  SELECT DISTINCT administrativeterritories.districtname, administrativeterritories.localityname   FROM administrativeterritories
  ORDER BY localityname LIMIT 10;
END
$$;
