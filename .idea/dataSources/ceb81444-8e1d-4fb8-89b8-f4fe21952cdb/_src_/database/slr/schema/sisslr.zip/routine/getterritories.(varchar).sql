create function getterritories(start character varying) returns TABLE(districtname character varying, localityname character varying)
LANGUAGE plpgsql
AS $$
begin
  Return query
  SELECT DISTINCT administrativeterritories.districtname, administrativeterritories.localityname   FROM administrativeterritories
  where administrativeterritories.localityname LIKE start
  ORDER BY localityname LIMIT 10;
END
$$;
