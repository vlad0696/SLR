create function search(start character[]) returns TABLE(name character varying)
LANGUAGE plpgsql
AS $$
begin
    Return query
    SELECT  name FROM ulandie WHERE ulandie.name LIKE (start) LIMIT 7;
  END

$$;
